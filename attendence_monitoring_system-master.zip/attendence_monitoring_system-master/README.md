attendence_monitoring_system
============================

It is a user-friendly, flexible and full featured employee attendance monitoring tool which allows controlling employees attendance by login timekeeping and attendance tracking
